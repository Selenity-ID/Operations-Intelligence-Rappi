/**
 * BigQuery Engine Simulation for Rappi Operations Intelligence Bot
 * Simulates Tabla_01 (Metrics) & Tabla_02 (Raw Orders) Data Warehouse tables.
 */

export interface MetricRow {
  COUNTRY: string;
  CITY: string;
  ZONE: string;
  ZONE_TYPE: string;
  METRIC: string;
  L0W_ROLL: number;
  L1W_ROLL: number;
  L2W_ROLL: number;
  L3W_ROLL: number;
  L4W_ROLL: number;
}

export interface OrderRow {
  COUNTRY: string;
  CITY: string;
  ZONE: string;
  L0W: number;
  L1W: number;
  L2W: number;
  L3W: number;
  L4W: number;
  L5W: number;
  L6W: number;
  L7W: number;
  L8W: number;
}

// Initial synthetic dataset for Tabla_01 (Metrics)
export const BQ_TABLE_METRICS: MetricRow[] = [
  // CDMX - MX
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Polanco', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.85, L1W_ROLL: 1.72, L2W_ROLL: 1.65, L3W_ROLL: 1.60, L4W_ROLL: 1.55 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Polanco', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.185, L1W_ROLL: 0.178, L2W_ROLL: 0.170, L3W_ROLL: 0.165, L4W_ROLL: 0.160 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Polanco', ZONE_TYPE: 'Wealthy', METRIC: '% PRO Users Who Breakeven', L0W_ROLL: 0.68, L1W_ROLL: 0.65, L2W_ROLL: 0.64, L3W_ROLL: 0.62, L4W_ROLL: 0.60 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Polanco', ZONE_TYPE: 'Wealthy', METRIC: 'Lead Penetration', L0W_ROLL: 0.45, L1W_ROLL: 0.42, L2W_ROLL: 0.40, L3W_ROLL: 0.38, L4W_ROLL: 0.35 },

  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Condesa', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.20, L1W_ROLL: 1.15, L2W_ROLL: 1.10, L3W_ROLL: 1.05, L4W_ROLL: 1.00 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Condesa', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.162, L1W_ROLL: 0.158, L2W_ROLL: 0.150, L3W_ROLL: 0.145, L4W_ROLL: 0.140 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Condesa', ZONE_TYPE: 'Wealthy', METRIC: '% PRO Users Who Breakeven', L0W_ROLL: 0.62, L1W_ROLL: 0.60, L2W_ROLL: 0.58, L3W_ROLL: 0.56, L4W_ROLL: 0.55 },

  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Iztapalapa', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -1.45, L1W_ROLL: -0.90, L2W_ROLL: -0.80, L3W_ROLL: -0.75, L4W_ROLL: -0.70 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Iztapalapa', ZONE_TYPE: 'Non Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.082, L1W_ROLL: 0.115, L2W_ROLL: 0.120, L3W_ROLL: 0.118, L4W_ROLL: 0.110 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Iztapalapa', ZONE_TYPE: 'Non Wealthy', METRIC: '% PRO Users Who Breakeven', L0W_ROLL: 0.32, L1W_ROLL: 0.41, L2W_ROLL: 0.40, L3W_ROLL: 0.38, L4W_ROLL: 0.36 },

  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Santa Fe', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 0.85, L1W_ROLL: 1.40, L2W_ROLL: 1.35, L3W_ROLL: 1.30, L4W_ROLL: 1.25 }, // Drop > 35%! Anomaly
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Santa Fe', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.140, L1W_ROLL: 0.145, L2W_ROLL: 0.142, L3W_ROLL: 0.140, L4W_ROLL: 0.138 },

  { COUNTRY: 'MX', CITY: 'Guadalajara', ZONE: 'Zapopan', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.10, L1W_ROLL: 1.05, L2W_ROLL: 1.02, L3W_ROLL: 0.98, L4W_ROLL: 0.95 },
  { COUNTRY: 'MX', CITY: 'Guadalajara', ZONE: 'Zapopan', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.155, L1W_ROLL: 0.150, L2W_ROLL: 0.148, L3W_ROLL: 0.145, L4W_ROLL: 0.140 },

  { COUNTRY: 'MX', CITY: 'Monterrey', ZONE: 'San Pedro', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 2.10, L1W_ROLL: 2.00, L2W_ROLL: 1.95, L3W_ROLL: 1.90, L4W_ROLL: 1.85 },
  { COUNTRY: 'MX', CITY: 'Monterrey', ZONE: 'San Pedro', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.205, L1W_ROLL: 0.198, L2W_ROLL: 0.190, L3W_ROLL: 0.185, L4W_ROLL: 0.180 },

  { COUNTRY: 'MX', CITY: 'Monterrey', ZONE: 'Apodaca', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -0.95, L1W_ROLL: -0.70, L2W_ROLL: -0.65, L3W_ROLL: -0.60, L4W_ROLL: -0.55 },

  // Bogotá - CO
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Chapinero', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.40, L1W_ROLL: 1.35, L2W_ROLL: 1.30, L3W_ROLL: 1.25, L4W_ROLL: 1.20 },
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Chapinero', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.172, L1W_ROLL: 0.168, L2W_ROLL: 0.165, L3W_ROLL: 0.160, L4W_ROLL: 0.155 },
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Chapinero', ZONE_TYPE: 'Wealthy', METRIC: '% PRO Users Who Breakeven', L0W_ROLL: 0.65, L1W_ROLL: 0.62, L2W_ROLL: 0.60, L3W_ROLL: 0.58, L4W_ROLL: 0.56 },

  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Usaquén', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.25, L1W_ROLL: 1.20, L2W_ROLL: 1.18, L3W_ROLL: 1.15, L4W_ROLL: 1.10 },
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Usaquén', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.165, L1W_ROLL: 0.160, L2W_ROLL: 0.158, L3W_ROLL: 0.155, L4W_ROLL: 0.150 },

  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Kennedy', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -1.85, L1W_ROLL: -1.20, L2W_ROLL: -1.10, L3W_ROLL: -1.00, L4W_ROLL: -0.90 }, // Critical offender
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Suba Sur', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -1.20, L1W_ROLL: -0.80, L2W_ROLL: -0.75, L3W_ROLL: -0.70, L4W_ROLL: -0.65 },

  { COUNTRY: 'CO', CITY: 'Medellín', ZONE: 'El Poblado', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.60, L1W_ROLL: 2.10, L2W_ROLL: 2.00, L3W_ROLL: 1.95, L4W_ROLL: 1.90 }, // Drop > 23%! Anomaly
  { COUNTRY: 'CO', CITY: 'Medellín', ZONE: 'El Poblado', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.180, L1W_ROLL: 0.185, L2W_ROLL: 0.182, L3W_ROLL: 0.178, L4W_ROLL: 0.175 },

  { COUNTRY: 'CO', CITY: 'Cali', ZONE: 'Ciudad Jardín', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 0.95, L1W_ROLL: 0.90, L2W_ROLL: 0.88, L3W_ROLL: 0.85, L4W_ROLL: 0.82 },

  // São Paulo / Brazil - BR
  { COUNTRY: 'BR', CITY: 'São Paulo', ZONE: 'Itaim Bibi', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 2.30, L1W_ROLL: 2.20, L2W_ROLL: 2.15, L3W_ROLL: 2.10, L4W_ROLL: 2.00 },
  { COUNTRY: 'BR', CITY: 'São Paulo', ZONE: 'Itaim Bibi', ZONE_TYPE: 'Wealthy', METRIC: 'Retail SST > SS CVR', L0W_ROLL: 0.210, L1W_ROLL: 0.205, L2W_ROLL: 0.200, L3W_ROLL: 0.195, L4W_ROLL: 0.190 },

  { COUNTRY: 'BR', CITY: 'São Paulo', ZONE: 'Capão Redondo', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -2.10, L1W_ROLL: -1.60, L2W_ROLL: -1.50, L3W_ROLL: -1.40, L4W_ROLL: -1.30 }, // Top offender

  { COUNTRY: 'BR', CITY: 'Rio de Janeiro', ZONE: 'Ipanema', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.75, L1W_ROLL: 1.70, L2W_ROLL: 1.65, L3W_ROLL: 1.60, L4W_ROLL: 1.55 },

  // Chile - CL
  { COUNTRY: 'CL', CITY: 'Santiago', ZONE: 'Las Condes', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.95, L1W_ROLL: 1.90, L2W_ROLL: 1.85, L3W_ROLL: 1.80, L4W_ROLL: 1.75 },
  { COUNTRY: 'CL', CITY: 'Santiago', ZONE: 'La Pintana', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -1.60, L1W_ROLL: -1.10, L2W_ROLL: -1.00, L3W_ROLL: -0.95, L4W_ROLL: -0.90 },

  // Peru - PE
  { COUNTRY: 'PE', CITY: 'Lima', ZONE: 'Miraflores', ZONE_TYPE: 'Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: 1.30, L1W_ROLL: 1.25, L2W_ROLL: 1.20, L3W_ROLL: 1.15, L4W_ROLL: 1.10 },
  { COUNTRY: 'PE', CITY: 'Lima', ZONE: 'San Juan de Lurigancho', ZONE_TYPE: 'Non Wealthy', METRIC: 'Gross Profit UE', L0W_ROLL: -1.35, L1W_ROLL: -0.95, L2W_ROLL: -0.90, L3W_ROLL: -0.85, L4W_ROLL: -0.80 },
];

// Initial synthetic dataset for Tabla_02 (Raw Orders)
export const BQ_TABLE_ORDERS: OrderRow[] = [
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Polanco', L0W: 145000, L1W: 141000, L2W: 138000, L3W: 135000, L4W: 132000, L5W: 129000, L6W: 126000, L7W: 122000, L8W: 118000 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Condesa', L0W: 112000, L1W: 109000, L2W: 106000, L3W: 104000, L4W: 101000, L5W: 99000, L6W: 97000, L7W: 95000, L8W: 92000 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Iztapalapa', L0W: 68000, L1W: 71000, L2W: 70000, L3W: 69000, L4W: 68000, L5W: 66000, L6W: 65000, L7W: 63000, L8W: 60000 },
  { COUNTRY: 'MX', CITY: 'CDMX', ZONE: 'Santa Fe', L0W: 92000, L1W: 98000, L2W: 96000, L3W: 95000, L4W: 93000, L5W: 91000, L6W: 89000, L7W: 87000, L8W: 84000 },
  { COUNTRY: 'MX', CITY: 'Guadalajara', ZONE: 'Zapopan', L0W: 88000, L1W: 85000, L2W: 83000, L3W: 81000, L4W: 79000, L5W: 77000, L6W: 75000, L7W: 73000, L8W: 70000 },
  { COUNTRY: 'MX', CITY: 'Monterrey', ZONE: 'San Pedro', L0W: 105000, L1W: 102000, L2W: 100000, L3W: 98000, L4W: 96000, L5W: 94000, L6W: 91000, L7W: 88000, L8W: 85000 },

  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Chapinero', L0W: 125000, L1W: 122000, L2W: 119000, L3W: 116000, L4W: 114000, L5W: 111000, L6W: 108000, L7W: 105000, L8W: 100000 },
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Usaquén', L0W: 98000, L1W: 95000, L2W: 93000, L3W: 91000, L4W: 89000, L5W: 87000, L6W: 85000, L7W: 82000, L8W: 80000 },
  { COUNTRY: 'CO', CITY: 'Bogotá', ZONE: 'Kennedy', L0W: 54000, L1W: 56000, L2W: 55000, L3W: 54000, L4W: 53000, L5W: 52000, L6W: 50000, L7W: 48000, L8W: 45000 },
  { COUNTRY: 'CO', CITY: 'Medellín', ZONE: 'El Poblado', L0W: 115000, L1W: 118000, L2W: 114000, L3W: 112000, L4W: 109000, L5W: 107000, L6W: 104000, L7W: 101000, L8W: 98000 },

  { COUNTRY: 'BR', CITY: 'São Paulo', ZONE: 'Itaim Bibi', L0W: 185000, L1W: 180000, L2W: 176000, L3W: 172000, L4W: 168000, L5W: 164000, L6W: 160000, L7W: 155000, L8W: 150000 },
  { COUNTRY: 'BR', CITY: 'São Paulo', ZONE: 'Capão Redondo', L0W: 62000, L1W: 64000, L2W: 63000, L3W: 62000, L4W: 60000, L5W: 59000, L6W: 57000, L7W: 55000, L8W: 52000 },

  { COUNTRY: 'CL', CITY: 'Santiago', ZONE: 'Las Condes', L0W: 95000, L1W: 92000, L2W: 90000, L3W: 88000, L4W: 86000, L5W: 84000, L6W: 82000, L7W: 80000, L8W: 78000 },

  { COUNTRY: 'PE', CITY: 'Lima', ZONE: 'Miraflores', L0W: 82000, L1W: 80000, L2W: 78000, L3W: 76000, L4W: 74000, L5W: 72000, L6W: 70000, L7W: 68000, L8W: 65000 },
];

/**
 * Anomaly Detection Algorithm (Simulates findAnomaliesInBigQuery)
 * Scans metrics where drop from L1W to L0W exceeds 15% WoW
 */
export function findAnomaliesInBigQuery() {
  const anomalies = [];
  for (const row of BQ_TABLE_METRICS) {
    if (row.L1W_ROLL > 0) {
      const drop = (row.L1W_ROLL - row.L0W_ROLL) / row.L1W_ROLL;
      if (drop > 0.15) {
        const dropPct = (drop * 100).toFixed(2);
        anomalies.push({
          Ciudad: row.CITY,
          Zona: row.ZONE,
          Metrica: row.METRIC,
          Caida_Porcentual: `${dropPct}%`,
          Semana_Anterior_L1W: row.L1W_ROLL,
          Semana_Actual_L0W: row.L0W_ROLL,
        });
      }
    }
  }
  return anomalies;
}

/**
 * Filter and query BigQuery database (Simulates queryBigQueryDatabase)
 */
export function queryBigQueryDatabase(filters: any) {
  if (!filters || Object.keys(filters).length === 0) {
    return 'No se detectaron filtros válidos.';
  }

  let results = BQ_TABLE_METRICS.slice();

  if (filters.country) {
    const c = String(filters.country).toLowerCase();
    results = results.filter((r) => r.COUNTRY.toLowerCase() === c);
  }
  if (filters.city) {
    const c = String(filters.city).toLowerCase();
    results = results.filter((r) => r.CITY.toLowerCase().includes(c));
  }
  if (filters.zone) {
    const z = String(filters.zone).toLowerCase();
    results = results.filter((r) => r.ZONE.toLowerCase().includes(z));
  }
  if (filters.zone_type) {
    const zt = String(filters.zone_type).toLowerCase();
    results = results.filter((r) => r.ZONE_TYPE.toLowerCase().includes(zt));
  }
  if (filters.metric) {
    const m = String(filters.metric).toLowerCase();
    results = results.filter((r) => r.METRIC.toLowerCase().includes(m));
  }

  if (filters.order === 'asc') {
    results.sort((a, b) => a.L0W_ROLL - b.L0W_ROLL);
  } else if (filters.order === 'desc') {
    results.sort((a, b) => b.L0W_ROLL - a.L0W_ROLL);
  }

  const limit = filters.limit ? Math.min(filters.limit, 50) : 30;
  results = results.slice(0, limit);

  if (results.length === 0) {
    return `La búsqueda en BigQuery no arrojó resultados para: ${JSON.stringify(filters)}`;
  }

  return JSON.stringify(results.map(r => ({
    Ciudad: r.CITY,
    Zona: r.ZONE,
    Tipo_Zona: r.ZONE_TYPE,
    Metrica: r.METRIC,
    Semana_L0W_Actual: r.L0W_ROLL,
    Semana_L1W: r.L1W_ROLL,
    Semana_L2W: r.L2W_ROLL,
    Semana_L3W: r.L3W_ROLL,
    Semana_L4W: r.L4W_ROLL
  })));
}

/**
 * Calculate Dashboard Aggregations (Simulates getDashboardData)
 */
export function getDashboardData(filters: { countries?: string[]; zoneTypes?: string[] } = {}) {
  let filteredMetrics = BQ_TABLE_METRICS.slice();
  let filteredOrders = BQ_TABLE_ORDERS.slice();

  if (filters.countries && filters.countries.length > 0) {
    filteredMetrics = filteredMetrics.filter(m => filters.countries!.includes(m.COUNTRY));
    filteredOrders = filteredOrders.filter(o => filters.countries!.includes(o.COUNTRY));
  }

  if (filters.zoneTypes && filters.zoneTypes.length > 0) {
    filteredMetrics = filteredMetrics.filter(m => filters.zoneTypes!.includes(m.ZONE_TYPE));
    const validZones = new Set(filteredMetrics.map(m => m.ZONE));
    filteredOrders = filteredOrders.filter(o => validZones.has(o.ZONE));
  }

  // Get distinct filter lists
  const countriesList = Array.from(new Set(BQ_TABLE_METRICS.map(r => r.COUNTRY))).sort();
  const zoneTypesList = Array.from(new Set(BQ_TABLE_METRICS.map(r => r.ZONE_TYPE))).sort();

  // Metrics processing
  let profitZones: { pais: string; ciudad: string; zona: string; tipo: string; profit: number }[] = [];
  let avgProfitSum = 0; let profitCount = 0;
  let cvrSumL0 = 0; let cvrSumL1 = 0; let cvrCount = 0;
  let beSumL0 = 0; let beSumL1 = 0; let beCount = 0;

  filteredMetrics.forEach(row => {
    if (row.METRIC === 'Gross Profit UE') {
      avgProfitSum += row.L0W_ROLL;
      profitCount++;
      profitZones.push({
        pais: row.COUNTRY,
        ciudad: row.CITY,
        zona: row.ZONE,
        tipo: row.ZONE_TYPE,
        profit: row.L0W_ROLL
      });
    } else if (row.METRIC === 'Retail SST > SS CVR') {
      cvrSumL0 += row.L0W_ROLL;
      cvrSumL1 += row.L1W_ROLL;
      cvrCount++;
    } else if (row.METRIC === '% PRO Users Who Breakeven') {
      beSumL0 += row.L0W_ROLL;
      beSumL1 += row.L1W_ROLL;
      beCount++;
    }
  });

  profitZones.sort((a, b) => a.profit - b.profit);
  const topOffenders = profitZones.slice(0, 5);
  const avgProfit = profitCount > 0 ? (avgProfitSum / profitCount) : 0;
  const detailedData = [...profitZones].sort((a, b) => b.profit - a.profit).slice(0, 100);

  const avgCvrL0 = cvrCount > 0 ? ((cvrSumL0 / cvrCount) * 100) : 0;
  const cvrWow = cvrCount > 0 ? (avgCvrL0 - ((cvrSumL1 / cvrCount) * 100)) : 0;

  const avgBeL0 = beCount > 0 ? ((beSumL0 / beCount) * 100) : 0;
  const beWow = beCount > 0 ? (avgBeL0 - ((beSumL1 / beCount) * 100)) : 0;

  // Orders processing
  let ordersTrend = [0, 0, 0, 0, 0, 0, 0, 0, 0];
  let totalOrdersL0 = 0;
  let wowGrowth = 0;

  if (filteredOrders.length > 0) {
    let l0Sum = 0, l1Sum = 0, l2Sum = 0, l3Sum = 0, l4Sum = 0, l5Sum = 0, l6Sum = 0, l7Sum = 0, l8Sum = 0;
    filteredOrders.forEach(o => {
      l0Sum += o.L0W;
      l1Sum += o.L1W;
      l2Sum += o.L2W;
      l3Sum += o.L3W;
      l4Sum += o.L4W;
      l5Sum += o.L5W;
      l6Sum += o.L6W;
      l7Sum += o.L7W;
      l8Sum += o.L8W;
    });

    totalOrdersL0 = l0Sum;
    wowGrowth = l1Sum > 0 ? ((l0Sum - l1Sum) / l1Sum) * 100 : 0;
    ordersTrend = [l8Sum, l7Sum, l6Sum, l5Sum, l4Sum, l3Sum, l2Sum, l1Sum, l0Sum];
  }

  return {
    success: true,
    kpis: {
      totalOrders: totalOrdersL0,
      wowGrowth: parseFloat(wowGrowth.toFixed(2)),
      avgProfit: parseFloat(avgProfit.toFixed(2)),
      cvr: parseFloat(avgCvrL0.toFixed(2)),
      cvrWow: parseFloat(cvrWow.toFixed(2)),
      breakeven: parseFloat(avgBeL0.toFixed(2)),
      breakevenWow: parseFloat(beWow.toFixed(2))
    },
    trends: { orders: ordersTrend },
    offenders: topOffenders,
    detailedData: detailedData,
    filtersData: { countries: countriesList, zoneTypes: zoneTypesList }
  };
}
