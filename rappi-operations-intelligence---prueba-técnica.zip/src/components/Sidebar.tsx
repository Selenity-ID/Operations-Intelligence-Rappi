import React from 'react';
import { Bot, LayoutDashboard, Rocket, Code, Sparkles } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  activeSection: 'chat' | 'dashboard' | 'pitch';
  onSwitchSection: (section: 'chat' | 'dashboard' | 'pitch') => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  activeSection,
  onSwitchSection,
}) => {
  return (
    <aside
      className={`fixed md:static inset-y-0 left-0 w-64 bg-white border-r border-gray-200 flex flex-col z-20 transition-all duration-300 transform shadow-lg md:shadow-none shrink-0 ${
        isOpen ? 'translate-x-0' : '-translate-x-full md:ml-[-16rem]'
      }`}
      style={{ top: '60px', height: 'calc(100vh - 60px)' }}
      id="main-sidebar"
    >
      <div className="p-4 border-b border-gray-100 bg-orange-50/50">
        <div className="flex items-center gap-2 text-xs font-bold text-[#FF441F] tracking-wide uppercase">
          <Sparkles className="w-4 h-4 text-[#FF441F]" />
          <span>Prueba Técnica SP&A</span>
        </div>
        <p className="text-xs text-gray-500 mt-1">
          Democratización de datos operacionales con IA y BigQuery
        </p>
      </div>

      <ul className="py-3 flex-1 space-y-1 px-2">
        <li>
          <button
            onClick={() => onSwitchSection('chat')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition-all text-left cursor-pointer ${
              activeSection === 'chat'
                ? 'bg-[#FF441F]/10 text-[#FF441F] font-semibold border-l-4 border-[#FF441F]'
                : 'text-gray-700 hover:bg-gray-100 hover:text-[#FF441F]'
            }`}
            id="nav-chat-btn"
          >
            <Bot className="w-5 h-5 text-[#FF441F]" />
            <span>Asistente Operativo</span>
          </button>
        </li>

        <li>
          <button
            onClick={() => onSwitchSection('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition-all text-left cursor-pointer ${
              activeSection === 'dashboard'
                ? 'bg-[#FF441F]/10 text-[#FF441F] font-semibold border-l-4 border-[#FF441F]'
                : 'text-gray-700 hover:bg-gray-100 hover:text-[#FF441F]'
            }`}
            id="nav-dashboard-btn"
          >
            <LayoutDashboard className="w-5 h-5 text-[#FF441F]" />
            <span>Dashboard Visual</span>
          </button>
        </li>

        <li className="pt-4 mt-2 border-t border-gray-100">
          <button
            onClick={() => onSwitchSection('pitch')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm transition-all text-left cursor-pointer ${
              activeSection === 'pitch'
                ? 'bg-[#FF441F]/10 text-[#FF441F] font-semibold border-l-4 border-[#FF441F]'
                : 'text-gray-700 hover:bg-gray-100 hover:text-[#FF441F]'
            }`}
            id="nav-pitch-btn"
          >
            <Rocket className="w-5 h-5 text-[#FF441F]" />
            <span>Arquitectura & Pitch</span>
          </button>
        </li>
      </ul>

      <div className="p-4 border-t border-gray-100 bg-gray-50/80 text-xs text-gray-500 flex flex-col gap-1.5">
        <div className="flex items-center gap-1 font-semibold text-gray-700">
          <Code className="w-3.5 h-3.5 text-[#FF441F]" />
          <span>Selene Jiménez</span>
        </div>
        <p>Prueba Técnica Rappi</p>
        <a
          href="https://github.com/Selenity-ID/Operations-Intelligence-Rappi"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#FF441F] font-medium hover:underline flex items-center gap-1 mt-1"
        >
          Ver en GitHub →
        </a>
      </div>
    </aside>
  );
};
