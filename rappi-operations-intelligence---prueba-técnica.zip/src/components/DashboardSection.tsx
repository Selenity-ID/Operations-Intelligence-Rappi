import React, { useState, useEffect } from 'react';
import Chart from 'react-apexcharts';
import {
  AlertTriangle,
  ShoppingBag,
  DollarSign,
  Store,
  Award,
  Info,
  ChevronDown,
  Filter,
  Search,
} from 'lucide-react';
import { DashboardData, FilterState } from '../types';

export const DashboardSection: React.FC = () => {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [filters, setFilters] = useState<FilterState>({
    countries: [],
    zoneTypes: [],
  });

  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);
  const [zoneTypeDropdownOpen, setZoneTypeDropdownOpen] = useState(false);
  const [tableSearch, setTableSearch] = useState('');

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const countriesQuery = filters.countries.join(',');
      const zoneTypesQuery = filters.zoneTypes.join(',');

      const res = await fetch(
        `/api/dashboard?countries=${encodeURIComponent(
          countriesQuery
        )}&zoneTypes=${encodeURIComponent(zoneTypesQuery)}`
      );
      const json = await res.json();
      if (json.success) {
        setData(json);
      }
    } catch (err) {
      console.error('Error fetching dashboard metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [filters]);

  const toggleCountry = (country: string) => {
    setFilters((prev) => {
      const exists = prev.countries.includes(country);
      return {
        ...prev,
        countries: exists
          ? prev.countries.filter((c) => c !== country)
          : [...prev.countries, country],
      };
    });
  };

  const toggleZoneType = (type: string) => {
    setFilters((prev) => {
      const exists = prev.zoneTypes.includes(type);
      return {
        ...prev,
        zoneTypes: exists
          ? prev.zoneTypes.filter((t) => t !== type)
          : [...prev.zoneTypes, type],
      };
    });
  };

  const numFmt = new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 1,
  });

  const moneyFmt = new Intl.NumberFormat('en-US', {
    notation: 'compact',
    maximumFractionDigits: 2,
  });

  // Chart configuration
  const chartOptions: ApexCharts.ApexOptions = {
    chart: {
      type: 'area',
      height: 320,
      fontFamily: 'Inter, sans-serif',
      toolbar: { show: false },
    },
    colors: ['#FF441F'],
    fill: {
      type: 'gradient',
      gradient: {
        shadeIntensity: 1,
        opacityFrom: 0.4,
        opacityTo: 0.05,
        stops: [0, 90, 100],
      },
    },
    dataLabels: { enabled: false },
    stroke: { curve: 'smooth', width: 3 },
    xaxis: {
      categories: ['L8W', 'L7W', 'L6W', 'L5W', 'L4W', 'L3W', 'L2W', 'L1W', 'L0W'],
      axisBorder: { show: false },
      axisTicks: { show: false },
    },
    yaxis: {
      labels: {
        formatter: (val: number) => numFmt.format(val),
      },
    },
    grid: { borderColor: '#F0F0F0', strokeDashArray: 4 },
  };

  const chartSeries = [
    {
      name: 'Total Órdenes',
      data: data?.trends?.orders || [0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
  ];

  const filteredDetailedData = (data?.detailedData || []).filter((row) => {
    if (!tableSearch) return true;
    const term = tableSearch.toLowerCase();
    return (
      row.ciudad.toLowerCase().includes(term) ||
      row.zona.toLowerCase().includes(term) ||
      row.pais.toLowerCase().includes(term) ||
      row.tipo.toLowerCase().includes(term)
    );
  });

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Operational Alert Banner */}
        {data?.offenders && data.offenders.length > 0 && data.offenders[0].profit < 0 && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-xl flex items-center gap-3 text-red-700 shadow-xs">
            <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
            <div className="text-xs md:text-sm font-semibold">
              <strong>Atención Operativa (Prueba Técnica):</strong> Se detectaron{' '}
              {data.offenders.length} zonas con rentabilidad crítica (Gross Profit UE negativo).
              Prioridad de revisión en {data.offenders[0].ciudad} ({data.offenders[0].zona}).
            </div>
          </div>
        )}

        {/* Header & Filters Bar */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight">
              Operations Analytics Dashboard
            </h2>
            <p className="text-xs text-gray-500">
              Métricas consolidadas de Data Warehouse BigQuery · Rappi SP&A
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Country Dropdown */}
            <div className="relative">
              <button
                onClick={() => setCountryDropdownOpen(!countryDropdownOpen)}
                className="px-4 py-2 bg-white border border-gray-200 rounded-full text-xs font-semibold text-gray-700 hover:border-[#FF441F] flex items-center gap-2 shadow-xs cursor-pointer"
              >
                <Filter className="w-3.5 h-3.5 text-[#FF441F]" />
                <span>
                  🌍 Países ({filters.countries.length > 0 ? filters.countries.length : 'Todos'})
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>

              {countryDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-xl z-20 p-2 space-y-1">
                  {(data?.filtersData?.countries || ['MX', 'CO', 'BR', 'CL', 'PE']).map(
                    (country) => (
                      <label
                        key={country}
                        className="flex items-center gap-2 px-3 py-1.5 text-xs text-gray-700 hover:bg-orange-50 rounded-lg cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={filters.countries.includes(country)}
                          onChange={() => toggleCountry(country)}
                          className="accent-[#FF441F] rounded"
                        />
                        <span>{country}</span>
                      </label>
                    )
                  )}
                </div>
              )}
            </div>

            {/* Zone Type Dropdown */}
            <div className="relative">
              <button
                onClick={() => setZoneTypeDropdownOpen(!zoneTypeDropdownOpen)}
                className="px-4 py-2 bg-white border border-gray-200 rounded-full text-xs font-semibold text-gray-700 hover:border-[#FF441F] flex items-center gap-2 shadow-xs cursor-pointer"
              >
                <Filter className="w-3.5 h-3.5 text-[#FF441F]" />
                <span>
                  📍 Tipos de Zona ({filters.zoneTypes.length > 0 ? filters.zoneTypes.length : 'Todos'})
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>

              {zoneTypeDropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-xl z-20 p-2 space-y-1">
                  {(data?.filtersData?.zoneTypes || ['Wealthy', 'Non Wealthy']).map((zt) => (
                    <label
                      key={zt}
                      className="flex items-center gap-2 px-3 py-1.5 text-xs text-gray-700 hover:bg-orange-50 rounded-lg cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={filters.zoneTypes.includes(zt)}
                        onChange={() => toggleZoneType(zt)}
                        className="accent-[#FF441F] rounded"
                      />
                      <span>{zt}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 4 KPI Grid Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* KPI 1 */}
          <div className="bg-white p-5 rounded-2xl shadow-xs border-l-4 border-[#FF441F] border-t border-r border-b border-gray-100 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <ShoppingBag className="w-4 h-4 text-[#FF441F]" />
                Órdenes Totales
              </span>
              <div className="group relative cursor-help">
                <Info className="w-3.5 h-3.5 text-gray-400" />
                <span className="absolute hidden group-hover:block bottom-full mb-1 left-1/2 -translate-x-1/2 w-48 bg-gray-900 text-white text-[10px] p-2 rounded-lg z-30 shadow-lg">
                  Volumen total de pedidos entregados en la semana L0W.
                </span>
              </div>
            </div>
            <div className="text-2xl font-black text-gray-900">
              {loading ? '...' : numFmt.format(data?.kpis?.totalOrders || 0)}
            </div>
            <div className="text-xs font-semibold mt-2">
              {(data?.kpis?.wowGrowth || 0) >= 0 ? (
                <span className="text-emerald-600">▲ {data?.kpis?.wowGrowth}% WoW</span>
              ) : (
                <span className="text-red-600">▼ {Math.abs(data?.kpis?.wowGrowth || 0)}% WoW</span>
              )}
            </div>
          </div>

          {/* KPI 2 */}
          <div className="bg-white p-5 rounded-2xl shadow-xs border-l-4 border-blue-600 border-t border-r border-b border-gray-100 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-blue-600" />
                Gross Profit UE
              </span>
              <div className="group relative cursor-help">
                <Info className="w-3.5 h-3.5 text-gray-400" />
                <span className="absolute hidden group-hover:block bottom-full mb-1 left-1/2 -translate-x-1/2 w-48 bg-gray-900 text-white text-[10px] p-2 rounded-lg z-30 shadow-lg">
                  Utilidad bruta promedio por orden (Unit Economics).
                </span>
              </div>
            </div>
            <div className="text-2xl font-black text-gray-900">
              {loading ? '...' : `$${moneyFmt.format(data?.kpis?.avgProfit || 0)}`}
            </div>
            <div className="text-xs font-semibold mt-2">
              {(data?.kpis?.avgProfit || 0) >= 0 ? (
                <span className="text-emerald-600">▲ Rentabilidad global positiva</span>
              ) : (
                <span className="text-red-600">▼ Margen en pérdida operativa</span>
              )}
            </div>
          </div>

          {/* KPI 3 */}
          <div className="bg-white p-5 rounded-2xl shadow-xs border-l-4 border-emerald-500 border-t border-r border-b border-gray-100 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Store className="w-4 h-4 text-emerald-500" />
                Retail CVR
              </span>
              <div className="group relative cursor-help">
                <Info className="w-3.5 h-3.5 text-gray-400" />
                <span className="absolute hidden group-hover:block bottom-full mb-1 left-1/2 -translate-x-1/2 w-48 bg-gray-900 text-white text-[10px] p-2 rounded-lg z-30 shadow-lg">
                  Conversión de búsqueda a sesión en Retail.
                </span>
              </div>
            </div>
            <div className="text-2xl font-black text-gray-900">
              {loading ? '...' : `${data?.kpis?.cvr || 0}%`}
            </div>
            <div className="text-xs font-semibold mt-2">
              {(data?.kpis?.cvrWow || 0) >= 0 ? (
                <span className="text-emerald-600">▲ {data?.kpis?.cvrWow}% vs L1W</span>
              ) : (
                <span className="text-red-600">▼ {Math.abs(data?.kpis?.cvrWow || 0)}% vs L1W</span>
              )}
            </div>
          </div>

          {/* KPI 4 */}
          <div className="bg-white p-5 rounded-2xl shadow-xs border-l-4 border-purple-600 border-t border-r border-b border-gray-100 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-purple-600" />
                Breakeven PRO
              </span>
              <div className="group relative cursor-help">
                <Info className="w-3.5 h-3.5 text-gray-400" />
                <span className="absolute hidden group-hover:block bottom-full mb-1 left-1/2 -translate-x-1/2 w-48 bg-gray-900 text-white text-[10px] p-2 rounded-lg z-30 shadow-lg">
                  Porcentaje de usuarios PRO que recuperan el costo de su suscripción.
                </span>
              </div>
            </div>
            <div className="text-2xl font-black text-gray-900">
              {loading ? '...' : `${data?.kpis?.breakeven || 0}%`}
            </div>
            <div className="text-xs font-semibold mt-2">
              {(data?.kpis?.breakevenWow || 0) >= 0 ? (
                <span className="text-emerald-600">▲ {data?.kpis?.breakevenWow}% retención</span>
              ) : (
                <span className="text-red-600">▼ {Math.abs(data?.kpis?.breakevenWow || 0)}% retención</span>
              )}
            </div>
          </div>
        </div>

        {/* Charts & Offenders Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Area Chart */}
          <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-xs border border-gray-200">
            <h3 className="font-bold text-sm text-gray-900 mb-4 flex items-center justify-between">
              <span>Evolución de Demanda (Órdenes L8W - L0W)</span>
              <span className="text-xs text-gray-400 font-normal">BigQuery Realtime</span>
            </h3>
            {loading ? (
              <div className="h-64 flex items-center justify-center text-xs text-gray-400">
                Cargando datos de tendencia...
              </div>
            ) : (
              <Chart
                options={chartOptions}
                series={chartSeries}
                type="area"
                height={300}
              />
            )}
          </div>

          {/* Top Offenders Table */}
          <div className="bg-white p-6 rounded-2xl shadow-xs border border-gray-200 flex flex-col">
            <h3 className="font-bold text-sm text-gray-900 mb-4 flex items-center justify-between">
              <span>Top Offenders: Profit</span>
              <span className="text-xs text-red-500 font-semibold">Críticos</span>
            </h3>
            <div className="overflow-x-auto flex-1">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="bg-orange-50 text-[#FF441F] font-bold">
                    <th className="p-2.5 rounded-l-lg">Ciudad</th>
                    <th className="p-2.5">Zona</th>
                    <th className="p-2.5 rounded-r-lg">GP UE</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {data?.offenders && data.offenders.length > 0 ? (
                    data.offenders.map((off, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="p-2.5 font-medium text-gray-800">{off.ciudad}</td>
                        <td className="p-2.5 text-gray-600">{off.zona}</td>
                        <td className="p-2.5">
                          <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold text-[11px]">
                            {off.profit < 0
                              ? `-$${moneyFmt.format(Math.abs(off.profit))}`
                              : `$${moneyFmt.format(off.profit)}`}
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="p-4 text-center text-gray-400">
                        No hay zonas con margen negativo.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Detailed Zone Table */}
        <div className="bg-white p-6 rounded-2xl shadow-xs border border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="font-bold text-sm text-gray-900">
                Detalle Operacional por Zona (Top 100)
              </h3>
              <p className="text-xs text-gray-400">
                Resultados filtrados dinámicamente desde el motor BigQuery
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                placeholder="Buscar por zona, ciudad o país..."
                className="w-full pl-9 pr-4 py-1.5 border border-gray-200 rounded-full text-xs focus:outline-none focus:border-[#FF441F]"
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-gray-200">
            <table className="w-full text-xs text-left whitespace-nowrap">
              <thead className="bg-gray-50 text-gray-500 font-semibold border-b border-gray-200">
                <tr>
                  <th className="p-3">País</th>
                  <th className="p-3">Ciudad</th>
                  <th className="p-3">Zona</th>
                  <th className="p-3">Tipo de Zona</th>
                  <th className="p-3">Gross Profit UE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredDetailedData.length > 0 ? (
                  filteredDetailedData.map((row, idx) => (
                    <tr key={idx} className="hover:bg-orange-50/30">
                      <td className="p-3 font-semibold text-gray-700">{row.pais}</td>
                      <td className="p-3 font-medium text-gray-900">{row.ciudad}</td>
                      <td className="p-3 text-gray-600">{row.zona}</td>
                      <td className="p-3 text-gray-500">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            row.tipo === 'Wealthy'
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          {row.tipo}
                        </span>
                      </td>
                      <td className="p-3">
                        <span
                          className={`px-2.5 py-1 rounded-full font-bold text-[11px] ${
                            row.profit >= 0
                              ? 'bg-emerald-100 text-emerald-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {row.profit < 0
                            ? `-$${moneyFmt.format(Math.abs(row.profit))}`
                            : `$${moneyFmt.format(row.profit)}`}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-gray-400">
                      No se encontraron zonas que coincidan con la búsqueda.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
