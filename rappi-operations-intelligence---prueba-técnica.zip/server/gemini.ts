import { GoogleGenAI } from '@google/genai';

// Shared Gemini AI Client instance
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface IntentionAnalysis {
  type: 'data_query' | 'anomaly_report' | 'general';
  filters?: {
    metric?: string;
    order?: 'asc' | 'desc';
    limit?: number;
    country?: string;
    city?: string;
    zone?: string;
    zone_type?: string;
  };
}

/**
 * Step 1: Classify user intent & parse parameters into structured JSON
 */
export async function classifyIntention(message: string, history: any[] = []): Promise<IntentionAnalysis> {
  const systemPrompt = `
    Eres el motor de enrutamiento de un bot de datos de Rappi para una Prueba Técnica.
    Analiza el mensaje del usuario y devuelve SOLO un JSON válido.
    Tipos permitidos: 'data_query' (métricas, zonas, ciudades, tendencias), 'anomaly_report' (alertas, anomalías), 'general' (saludos, preguntas sobre la app o prueba técnica).
    Si es 'data_query', incluye un objeto 'filters' con las claves que detectes.
   
    REGLAS DE BÚSQUEDA:
    - Si el usuario pide "mejores", "top", "mayor" agrega "order": "desc".
    - Si pide "peores", "bottom", "menor" agrega "order": "asc".
    - Si pide cantidad agrega "limit": numero.
    - Si menciona "Wealthy" o "Non Wealthy", va en la clave "zone_type".
    - Si menciona un país (ej. "México", "Colombia", "Brasil", "Chile", "Perú"), conviértelo a su código ISO de 2 letras ("MX", "CO", "BR", "CL", "PE") en la clave "country".
    - Si menciona una ciudad (ej. "CDMX", "Bogotá", "Medellín", "São Paulo"), agrégala en "city".
    - Si menciona una zona (ej. "Polanco", "Chapinero", "Poblado"), agrégala en "zone".
   
    REGLA ESTRICTA DE DICCIONARIO DE DATOS (Mapeo de Métricas):
    Cuando el usuario pregunte por métricas, DEBES mapear su lenguaje natural a los nombres EXACTOS de la base de datos en la clave "metric":
    - Si mencionan "Retail CVR" o conversión de retail -> "Retail SST > SS CVR"
    - Si mencionan "Breakeven" o retención PRO -> "% PRO Users Who Breakeven"
    - Si mencionan "Gross Profit", "profit" o rentabilidad -> "Gross Profit UE"
    - Si mencionan "Lead Penetration" -> "Lead Penetration"
    NUNCA inventes nombres de métricas en el JSON que no sean estos.

    Formato esperado de ejemplo:
    {"type": "data_query", "filters": {"metric": "Retail SST > SS CVR", "order": "desc", "limit": 5, "country": "MX"}}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: message,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.1,
      },
    });

    const jsonText = response.text?.trim() || '{}';
    return JSON.parse(jsonText);
  } catch (error) {
    console.error('Error classifying intention:', error);
    return { type: 'general' };
  }
}

/**
 * Step 2: Generate natural language response / executive report in HTML
 */
export async function generateNaturalLanguage(
  userMessage: string,
  dataContext: string,
  history: { role: string; content: string }[] = []
): Promise<string> {
  const systemPrompt = `
    Eres un Analista Senior de Operaciones en Rappi ejecutando una demostración de Prueba Técnica de Inteligencia Operacional.
   
    REGLA DE IDENTIDAD Y CONVERSACIÓN (PRIORIDAD MÁXIMA):
    Si el usuario te saluda, hace una pregunta general, o pregunta qué puedes hacer o qué métricas puedes analizar, DEBES responder de forma conversacional, amigable y natural (SIN usar la tabla HTML).
    Preséntate como un experto analista en Rappi (aclarando con cordialidad que esta es la solución para la Prueba Técnica) y lista las métricas principales que puedes analizar:
    1. Gross Profit UE (Rentabilidad y Unit Economics)
    2. Retail CVR (Tasa de conversión de búsqueda a sesión en Retail)
    3. Breakeven PRO (Porcentaje de usuarios PRO que recuperan su membresía)
    4. Órdenes Totales y Evolución de la Demanda
    PROHIBICIÓN ESTRICTA: NUNCA menciones la palabra "JSON", "Prompt", "BigQuery", "Contexto" ni expliques tu arquitectura interna. Nunca digas que te faltan datos si solo te están saludando.

    REGLA PARA CONSULTAS DE DATOS OPERATIVOS:
    Si el usuario pide analizar datos específicos o reportes, responde usando EXCLUSIVAMENTE los datos proporcionados en el "Contexto de datos". En este caso, DEBES usar la siguiente REGLA ESTRICTA DE FORMATO HTML PARA EXPORTACIÓN:
    <div class="rappi-report-card">
      <h3 class="rappi-report-title">📊 [Título del Análisis Operativo]</h3>
      <p class="rappi-report-summary">[Breve resumen ejecutivo de los hallazgos]</p>
      <table class="rappi-table">
        <thead>
          <tr><th>Ciudad</th><th>Zona/Tipo</th><th>Métrica</th><th>Valor L0W</th><th>Tendencia</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>[Ciudad]</td><td>[Zona]</td><td>[Nombre Métrica]</td>
            <td><strong>[Valor]</strong><div class="rappi-bar-container"><div class="rappi-bar" style="width:[PORCENTAJE CALCULADO 0-100]%;"></div></div></td>
            <td>[Ej. ▲ 2% o ▼ -5%]</td>
          </tr>
        </tbody>
      </table>
      <div class="rappi-report-footer">
        <p><strong>💡 Insight Operativo:</strong> [Recomendación concreta de acción basada en los datos]</p>
        <button class="btn-pdf" onclick="descargarPDF(this)">📄 Descargar Reporte PDF</button>
      </div>
    </div>
   
    Contexto de datos: ${dataContext}
  `;

  try {
    const contents: any[] = history.map((msg) => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }],
    }));
    contents.push({ role: 'user', parts: [{ text: userMessage }] });

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3,
      },
    });

    return response.text || 'No fue posible generar una respuesta.';
  } catch (error: any) {
    console.error('Error generating response from Gemini:', error);
    return `Ocurrió un inconveniente al procesar la consulta con Gemini API: ${error?.message || 'Error de servicio'}`;
  }
}
