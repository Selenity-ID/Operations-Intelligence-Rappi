export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

export interface DashboardKPIs {
  totalOrders: number;
  wowGrowth: number;
  avgProfit: number;
  cvr: number;
  cvrWow: number;
  breakeven: number;
  breakevenWow: number;
}

export interface OffenderZone {
  pais: string;
  ciudad: string;
  zona: string;
  profit: number;
}

export interface DetailedZoneRecord {
  pais: string;
  ciudad: string;
  zona: string;
  tipo: string;
  profit: number;
}

export interface DashboardData {
  success: boolean;
  error?: string;
  kpis: DashboardKPIs;
  trends: {
    orders: number[];
  };
  offenders: OffenderZone[];
  detailedData: DetailedZoneRecord[];
  filtersData: {
    countries: string[];
    zoneTypes: string[];
  };
}

export interface FilterState {
  countries: string[];
  zoneTypes: string[];
}

export interface UserSession {
  email: string | null;
  name: string | null;
  isAdmin: boolean;
  queriesRemaining: number;
  maxQueries: number;
  totalQueriesUsed: number;
}

export interface AnomalyItem {
  Ciudad: string;
  Zona: string;
  Metrica: string;
  Caida_Porcentual: string;
  Semana_Anterior_L1W: number;
  Semana_Actual_L0W: number;
}

