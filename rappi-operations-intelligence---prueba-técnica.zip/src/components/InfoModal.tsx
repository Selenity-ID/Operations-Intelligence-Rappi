import React from 'react';
import { X, Bot, ChevronDown, BookOpen } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[85vh] overflow-y-auto p-6 relative shadow-2xl border border-gray-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-[#FF441F] p-1 transition-colors cursor-pointer"
          title="Cerrar modal"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-2 text-xl font-bold text-gray-900 border-b border-gray-100 pb-3 mb-4">
          <Bot className="w-6 h-6 text-[#FF441F]" />
          <span>Sobre Operations IA</span>
        </div>

        <div className="text-sm text-gray-600 space-y-4">
          <p>
            Este bot es un agente impulsado por Inteligencia Artificial (Gemini API + BigQuery)
            desarrollado por <strong>Selene Jiménez</strong> como <strong>Prueba Técnica</strong> para
            democratizar el acceso a la información operativa en Rappi.
          </p>

          <div>
            <h4 className="font-bold text-gray-800 mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wider">
              <BookOpen className="w-4 h-4 text-[#FF441F]" />
              Casos de Uso Soportados
            </h4>
            <ul className="list-disc pl-5 space-y-1 text-xs">
              <li>
                <strong>Consultas Directas:</strong> <em>"¿Cuáles son las 5 zonas con mayor Retail CVR?"</em>
              </li>
              <li>
                <strong>Comparaciones:</strong> <em>"Compara el Gross Profit entre zonas Wealthy y Non Wealthy en México."</em>
              </li>
              <li>
                <strong>Análisis Histórico:</strong> <em>"¿Cómo evolucionó el Gross Profit en Chapinero?"</em>
              </li>
              <li>
                <strong>Reportes Automáticos:</strong> <em>"Genera un reporte de anomalías."</em>
              </li>
            </ul>
          </div>

          <hr className="border-gray-100 my-3" />

          <div>
            <h4 className="font-bold text-gray-800 mb-1 text-xs uppercase tracking-wider">
              📊 Diccionario de Métricas Disponibles
            </h4>
            <p className="text-xs text-gray-400 mb-3">
              Haz clic en cada categoría para desplegar las métricas operacionales.
            </p>

            <div className="space-y-2">
              <details className="bg-gray-50 p-3 rounded-xl border border-gray-100 group cursor-pointer">
                <summary className="font-semibold text-xs text-gray-800 flex justify-between items-center list-none">
                  <span>💰 Rentabilidad y Conversión (Core)</span>
                  <ChevronDown className="w-4 h-4 text-gray-400 group-open:rotate-180 transition-transform" />
                </summary>
                <ul className="mt-2.5 pt-2 border-t border-gray-200 text-xs space-y-1.5 pl-2 text-gray-600">
                  <li><strong>Gross Profit UE:</strong> Rentabilidad o margen bruto promedio por orden (Unit Economics).</li>
                  <li><strong>% PRO Users Who Breakeven:</strong> Porcentaje de usuarios PRO que recuperan el costo de su membresía.</li>
                  <li><strong>Retail SST &gt; SS CVR:</strong> Tasa de conversión de búsqueda a selección de tienda en Retail.</li>
                  <li><strong>Lead Penetration:</strong> Efectividad convirtiendo tiendas prospecto a comercios activos.</li>
                </ul>
              </details>

              <details className="bg-gray-50 p-3 rounded-xl border border-gray-100 group cursor-pointer">
                <summary className="font-semibold text-xs text-gray-800 flex justify-between items-center list-none">
                  <span>📈 Volumen y Demanda</span>
                  <ChevronDown className="w-4 h-4 text-gray-400 group-open:rotate-180 transition-transform" />
                </summary>
                <ul className="mt-2.5 pt-2 border-t border-gray-200 text-xs space-y-1.5 pl-2 text-gray-600">
                  <li><strong>Orders:</strong> Volumen total de pedidos entregados en la zona y período consultado (L0W).</li>
                </ul>
              </details>

              <details className="bg-gray-50 p-3 rounded-xl border border-gray-100 group cursor-pointer">
                <summary className="font-semibold text-xs text-gray-800 flex justify-between items-center list-none">
                  <span>🛍️ Experiencia y Comportamiento del Usuario</span>
                  <ChevronDown className="w-4 h-4 text-gray-400 group-open:rotate-180 transition-transform" />
                </summary>
                <ul className="mt-2.5 pt-2 border-t border-gray-200 text-xs space-y-1.5 pl-2 text-gray-600">
                  <li><strong>Perfect Orders:</strong> Pedidos completados sin cancelaciones ni defectos.</li>
                  <li><strong>MLTV Top Verticals Adoption:</strong> Usuarios con adopción en múltiples verticales.</li>
                  <li><strong>Pro Adoption:</strong> Porcentaje de usuarios con suscripción Pro.</li>
                  <li><strong>Turbo Adoption:</strong> Adopción de entregas ultrarrápidas Turbo.</li>
                </ul>
              </details>

              <details className="bg-gray-50 p-3 rounded-xl border border-gray-100 group cursor-pointer">
                <summary className="font-semibold text-xs text-gray-800 flex justify-between items-center list-none">
                  <span>🏪 Performance de Restaurantes</span>
                  <ChevronDown className="w-4 h-4 text-gray-400 group-open:rotate-180 transition-transform" />
                </summary>
                <ul className="mt-2.5 pt-2 border-t border-gray-200 text-xs space-y-1.5 pl-2 text-gray-600">
                  <li><strong>% Restaurants Sessions With Optimal Assortment:</strong> Sesiones con surtido amplio.</li>
                  <li><strong>Restaurants Markdowns / GMV:</strong> Porcentaje de descuentos sobre GMV.</li>
                  <li><strong>Restaurants SST &gt; SS CVR:</strong> Conversión de categoría a restaurant.</li>
                  <li><strong>Restaurants SS &gt; ATC CVR:</strong> Conversión de restaurant a agregar al carrito.</li>
                </ul>
              </details>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
