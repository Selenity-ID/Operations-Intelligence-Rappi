import React from 'react';
import { Menu, ShieldAlert, Zap, UserCheck, Lock } from 'lucide-react';
import { UserSession } from '../types';

interface HeaderProps {
  onToggleSidebar: () => void;
  session: UserSession | null;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleSidebar,
  session,
  onOpenAuthModal,
}) => {
  return (
    <header className="bg-[#FF441F] text-white px-4 md:px-6 h-15 flex items-center justify-between shadow-md z-30 shrink-0">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="p-1 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          title="Toggle Navigation Menu"
          id="toggle-sidebar-btn"
        >
          <Menu className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          {/* Rappi Logo text */}
          <div className="flex items-center gap-1.5 font-extrabold text-xl tracking-tight bg-white text-[#FF441F] px-2.5 py-0.5 rounded-full shadow-xs">
            <span>Rappi</span>
          </div>
          <h1 className="text-base md:text-lg font-bold whitespace-nowrap text-white">
            Operations Intelligence
          </h1>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Remaining Queries / Admin Badge */}
        <button
          onClick={onOpenAuthModal}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer shadow-xs ${
            session?.isAdmin
              ? 'bg-emerald-500 hover:bg-emerald-600 text-white border border-emerald-400'
              : (session?.queriesRemaining || 0) > 0
              ? 'bg-white text-[#FF441F] hover:bg-orange-50 font-extrabold'
              : 'bg-red-900 text-red-100 animate-pulse border border-red-400'
          }`}
          title="Ver o reiniciar límite de consultas"
          id="auth-status-btn"
        >
          {session?.isAdmin ? (
            <>
              <UserCheck className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Admin (Selene):</span>
              <span>⚡ ∞ Consultas</span>
            </>
          ) : (
            <>
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>
                {session?.queriesRemaining ?? 5}/{session?.maxQueries ?? 5} Consultas
              </span>
            </>
          )}
        </button>

        <span className="hidden md:inline-flex items-center gap-1 text-xs font-bold bg-white/20 px-3 py-1 rounded-full border border-white/30 tracking-wide text-white">
          <ShieldAlert className="w-3.5 h-3.5 text-yellow-200" />
          PRUEBA TÉCNICA
        </span>
      </div>
    </header>
  );
};

