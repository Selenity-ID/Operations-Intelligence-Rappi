import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Trash2,
  HelpCircle,
  Bot,
  User,
  Sparkles,
  Download,
  Search,
  Activity,
  AlertTriangle,
  Lightbulb,
  Lock,
  Zap,
} from 'lucide-react';
import { ChatMessage, UserSession } from '../types';

interface ChatSectionProps {
  onOpenInfoModal: () => void;
  onOpenDeleteModal: () => void;
  resetTrigger: number;
  session: UserSession | null;
  onUpdateSession: (s: UserSession) => void;
  onOpenAuthModal: () => void;
}

export const ChatSection: React.FC<ChatSectionProps> = ({
  onOpenInfoModal,
  onOpenDeleteModal,
  resetTrigger,
  session,
  onUpdateSession,
  onOpenAuthModal,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [morphIconIndex, setMorphIconIndex] = useState(0);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const isLimitReached = !session?.isAdmin && (session?.queriesRemaining ?? 5) <= 0;

  const morphIcons = [<Activity key="1" />, <Search key="2" />, <Sparkles key="3" />, <Lightbulb key="4" />];


  // Daily dynamic greeting helper
  const getDailyGreeting = () => {
    const saludos = [
      '¡Feliz Domingo! 🛋️ Los servidores están relajados, pero si hay una urgencia operativa, aquí estoy. ¿Qué miramos en esta Prueba Técnica?',
      '¡Buen Lunes! ☕ Espero que tu café esté más fuerte que nuestras queries hoy. ¿Por dónde empezamos el análisis operacional?',
      '¡Buen Martes! 🚀 Ya sobrevivimos al lunes. ¿Qué métricas o tendencias analíticas revisamos en esta prueba técnica?',
      '¡Mitad de semana! 🐪 Los KPIs no descansan. ¿Qué insight crítico o anomalía buscamos hoy?',
      '¡Juernes! 🎉 Ya casi olemos el fin de semana, pero primero, asegurémonos de que el Profit esté en verde. ¿En qué nos enfocamos?',
      '¡Por fin Viernes! 🍻 Prometo que este análisis será rápido y preciso para que puedas cerrar la semana con broche de oro. ¿Qué revisamos?',
      '¡Buen Sábado! 🕶️ Si estás analizando métricas hoy, definitivamente mereces un ascenso. ¿Qué anomalía buscamos?',
    ];
    const day = new Date().getDay();
    return saludos[day];
  };

  const getTimestampWithDate = () => {
    const now = new Date();
    const dateStr = now.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
    const timeStr = now.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
    return `${dateStr}, ${timeStr}`;
  };

  // Attach global descargarPDF function to window for HTML report card button clicks
  useEffect(() => {
    (window as any).descargarPDF = function (btnElement: HTMLElement) {
      const card = btnElement.closest('.rappi-report-card');
      if (!card) return;

      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Reporte Operacional Rappi - Prueba Técnica</title>
              <style>
                body { font-family: sans-serif; padding: 20px; color: #030303; }
                .rappi-report-card { border: 1px solid #EAEAEA; padding: 24px; border-radius: 12px; }
                .rappi-report-title { color: #FF441F; margin-top: 0; font-size: 20px; }
                .rappi-report-summary { color: #737373; font-size: 14px; margin-bottom: 16px; }
                table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                th, td { border-bottom: 1px solid #eee; padding: 10px; text-align: left; font-size: 13px; }
                th { background: #F5F5F7; color: #737373; }
                .btn-pdf { display: none; }
                .rappi-bar-container { background: #f0f0f0; height: 8px; border-radius: 4px; overflow: hidden; margin-top: 4px; }
                .rappi-bar { background: #FF441F; height: 100%; }
                .rappi-report-footer { background: rgba(255, 68, 31, 0.05); padding: 12px; border-radius: 8px; border-left: 4px solid #FF441F; margin-top: 16px; font-size: 13px; }
              </style>
            </head>
            <body>
              ${card.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        setTimeout(() => {
          printWindow.print();
        }, 300);
      }
    };

    return () => {
      delete (window as any).descargarPDF;
    };
  }, []);

  // Load chat history or initialize on mount / reset
  useEffect(() => {
    const saved = localStorage.getItem('rappi_chat_history');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setMessages(parsed);
          return;
        }
      } catch (e) {
        console.error('Failed parsing chat history:', e);
      }
    }

    // Default greeting
    const initialGreeting: ChatMessage = {
      id: 'msg-init',
      sender: 'bot',
      text: getDailyGreeting(),
      timestamp: getTimestampWithDate(),
    };
    setMessages([initialGreeting]);
    localStorage.setItem('rappi_chat_history', JSON.stringify([initialGreeting]));
  }, [resetTrigger]);

  // Scroll to bottom on message change
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Morphing icon timer
  useEffect(() => {
    if (!isLoading) return;
    const interval = setInterval(() => {
      setMorphIconIndex((prev) => (prev + 1) % morphIcons.length);
    }, 600);
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    if (isLimitReached) {
      onOpenAuthModal();
      return;
    }

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: getTimestampWithDate(),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const historyPayload = newMessages.slice(-8).map((m) => ({
        role: m.sender === 'user' ? 'user' : 'assistant',
        content: m.text,
      }));

      const sessionId = localStorage.getItem('rappi_session_id') || 'default';

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': sessionId,
        },
        body: JSON.stringify({
          message: text,
          history: historyPayload,
        }),
      });

      const data = await res.json();

      if (data.session) {
        onUpdateSession(data.session);
      }

      const botResponseText = data.success
        ? data.message
        : data.message || 'Error al procesar la consulta en la base de datos.';

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: botResponseText,
        timestamp: getTimestampWithDate(),
      };

      const updated = [...newMessages, botMsg];
      setMessages(updated);
      localStorage.setItem('rappi_chat_history', JSON.stringify(updated));

      if (data.isLimitReached) {
        onOpenAuthModal();
      }
    } catch (error: any) {
      console.error('Chat error:', error);
      const errorMsg: ChatMessage = {
        id: `bot-err-${Date.now()}`,
        sender: 'bot',
        text: 'Hubo una interrupción en la conexión con el servidor. Por favor reintenta.',
        timestamp: getTimestampWithDate(),
      };
      const updated = [...newMessages, errorMsg];
      setMessages(updated);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSendMessage();
  };

  // Trigger PDF print/download for report card
  const handleDownloadPDF = (e: React.MouseEvent) => {
    const card = (e.currentTarget as HTMLElement).closest('.rappi-report-card');
    if (!card) return;

    // Create a print-friendly window
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Reporte Operacional Rappi - Prueba Técnica</title>
            <style>
              body { font-family: sans-serif; padding: 20px; color: #030303; }
              .rappi-report-card { border: 1px solid #EAEAEA; padding: 24px; border-radius: 12px; }
              .rappi-report-title { color: #FF441F; margin-top: 0; }
              table { width: 100%; border-collapse: collapse; margin-top: 16px; }
              th, td { border-bottom: 1px solid #eee; padding: 10px; text-align: left; }
              th { background: #F5F5F7; color: #737373; }
              .btn-pdf { display: none; }
              .rappi-bar-container { background: #f0f0f0; height: 8px; border-radius: 4px; overflow: hidden; margin-top: 4px; }
              .rappi-bar { background: #FF441F; height: 100%; }
              .rappi-report-footer { background: rgba(255, 68, 31, 0.05); padding: 12px; border-radius: 8px; border-left: 4px solid #FF441F; margin-top: 16px; }
            </style>
          </head>
          <body>
            ${card.outerHTML}
          </body>
        </html>
      `);
      printWindow.document.close();
      setTimeout(() => {
        printWindow.print();
      }, 500);
    }
  };

  // Helper to safely format text / HTML report card
  const renderMessageContent = (msg: ChatMessage) => {
    if (msg.text.includes('rappi-report-card') || msg.text.includes('<div class=')) {
      return (
        <div
          className="prose prose-sm max-w-none text-gray-900"
          dangerouslySetInnerHTML={{ __html: msg.text }}
          onClick={(e) => {
            const target = e.target as HTMLElement;
            if (target && target.classList.contains('btn-pdf')) {
              handleDownloadPDF(e as any);
            }
          }}
        />
      );
    }

    // Format Markdown bold **text**
    const formatted = msg.text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n/g, '<br/>');

    return (
      <div
        className="leading-relaxed text-sm"
        dangerouslySetInnerHTML={{ __html: formatted }}
      />
    );
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-gray-50 overflow-hidden">
      {/* Top Header Bar inside Chat */}
      <div className="bg-white px-6 py-3 border-b border-gray-200 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-orange-100 rounded-lg text-[#FF441F]">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
              Analista Operativo de Inteligencia (IA)
            </h3>
            <p className="text-xs text-gray-500">
              Prueba Técnica SP&A · Rappi Data Warehouse Router
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenDeleteModal}
            className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
            title="Borrar Historial"
            id="clear-chat-btn"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenInfoModal}
            className="p-2 text-[#FF441F] hover:bg-orange-50 rounded-lg transition-colors cursor-pointer"
            title="¿Cómo usar este bot?"
            id="help-chat-btn"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Suggestion Chips */}
      <div className="bg-white/80 px-6 py-2 border-b border-gray-100 flex items-center gap-2 overflow-x-auto text-xs shrink-0 no-scrollbar">
        <span className="font-bold text-gray-400 uppercase text-[10px] tracking-wider shrink-0">
          Sugerencias:
        </span>
        <button
          onClick={() => handleSendMessage('Genera un reporte de anomalías')}
          className="px-3 py-1 bg-orange-50 text-[#FF441F] font-medium rounded-full border border-orange-200 hover:bg-orange-100 transition-colors shrink-0 cursor-pointer"
        >
          🚨 Reporte de anomalías
        </button>
        <button
          onClick={() => handleSendMessage('¿Cuáles son las 5 mejores zonas en Retail CVR?')}
          className="px-3 py-1 bg-gray-100 text-gray-700 font-medium rounded-full border border-gray-200 hover:bg-gray-200 transition-colors shrink-0 cursor-pointer"
        >
          🏆 Top 5 Retail CVR
        </button>
        <button
          onClick={() => handleSendMessage('¿Cuál es el Gross Profit en Chapinero?')}
          className="px-3 py-1 bg-gray-100 text-gray-700 font-medium rounded-full border border-gray-200 hover:bg-gray-200 transition-colors shrink-0 cursor-pointer"
        >
          💰 Profit Chapinero
        </button>
        <button
          onClick={() => handleSendMessage('Compara las zonas Wealthy vs Non Wealthy en México')}
          className="px-3 py-1 bg-gray-100 text-gray-700 font-medium rounded-full border border-gray-200 hover:bg-gray-200 transition-colors shrink-0 cursor-pointer"
        >
          ⚖️ Wealthy vs Non Wealthy MX
        </button>
      </div>

      {/* Chat Messages List */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 ${
              msg.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.sender === 'bot' && (
              <div className="w-8 h-8 rounded-full bg-[#FF441F] text-white flex items-center justify-center text-xs font-bold shrink-0 shadow-xs mt-1">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl p-4 shadow-xs ${
                msg.sender === 'user'
                  ? 'bg-[#FF441F] text-white rounded-tr-none'
                  : 'bg-white text-gray-900 border border-gray-200 rounded-tl-none'
              }`}
            >
              {renderMessageContent(msg)}
              <span
                className={`text-[10px] block text-right mt-2 ${
                  msg.sender === 'user' ? 'text-white/80' : 'text-gray-400'
                }`}
              >
                {msg.timestamp}
              </span>
            </div>

            {msg.sender === 'user' && (
              <div className="w-8 h-8 rounded-full bg-gray-800 text-white flex items-center justify-center text-xs font-bold shrink-0 shadow-xs mt-1">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#FF441F] text-white flex items-center justify-center shrink-0 shadow-xs animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-white border border-orange-200 text-[#FF441F] text-xs font-semibold px-4 py-2.5 rounded-2xl rounded-tl-none flex items-center gap-2 shadow-xs">
              <span className="animate-spin text-[#FF441F]">
                {morphIcons[morphIconIndex]}
              </span>
              <span>Procesando reglas de negocio & SQL BigQuery...</span>
            </div>
          </div>
        )}

        <div ref={chatBottomRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-gray-200 shrink-0">
        {isLimitReached ? (
          <div className="max-w-4xl mx-auto bg-red-50 border border-red-200 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 animate-fadeIn">
            <div className="flex items-center gap-3 text-xs text-red-800 font-medium">
              <div className="p-2 bg-red-100 rounded-full text-red-600 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <strong className="block text-red-900 font-bold text-sm">
                  Límite de consultas alcanzado (0/{session?.maxQueries || 5})
                </strong>
                <span>
                  Inicia sesión con Google como Administradora (selene.jimenez.id@gmail.com) para reiniciar tus intentos.
                </span>
              </div>
            </div>
            <button
              onClick={onOpenAuthModal}
              className="bg-[#FF441F] hover:bg-[#E33C1B] text-white px-5 py-2.5 rounded-xl font-bold text-xs shrink-0 cursor-pointer shadow-xs transition-all flex items-center gap-1.5"
            >
              <Zap className="w-4 h-4" />
              <span>Desbloquear Intentos</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 max-w-4xl mx-auto">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ej: Genera un reporte de anomalías o consulta la conversión de Retail..."
              className="flex-1 px-5 py-3 border border-gray-300 rounded-full text-sm focus:outline-none focus:border-[#FF441F] focus:ring-2 focus:ring-[#FF441F]/10 transition-all"
              disabled={isLoading}
              id="chat-user-input"
            />
            <button
              onClick={() => handleSendMessage()}
              disabled={isLoading || !input.trim()}
              className="bg-[#FF441F] hover:bg-[#E33C1B] disabled:opacity-50 text-white px-6 py-3 rounded-full font-semibold text-sm flex items-center gap-2 transition-colors cursor-pointer shadow-xs"
              id="chat-send-btn"
            >
              <span>Enviar</span>
              <Send className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
