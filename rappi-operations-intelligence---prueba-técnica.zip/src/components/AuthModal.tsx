import React, { useState } from 'react';
import { X, ShieldCheck, UserCheck, Key, Lock, Sparkles, CheckCircle } from 'lucide-react';
import { UserSession } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSession: UserSession | null;
  onLoginSuccess: (session: UserSession) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentSession,
  onLoginSuccess,
}) => {
  const [customEmail, setCustomEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleGoogleLogin = async (emailToUse: string, nameToUse?: string) => {
    setLoading(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/auth/google-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': localStorage.getItem('rappi_session_id') || 'default',
        },
        body: JSON.stringify({
          email: emailToUse,
          name: nameToUse || emailToUse.split('@')[0],
        }),
      });

      const data = await res.json();
      if (data.success && data.session) {
        onLoginSuccess(data.session);
        onClose();
      } else {
        setErrorMsg(data.message || 'Error al iniciar sesión con Google');
      }
    } catch (err: any) {
      setErrorMsg('No se pudo establecer conexión con el servidor de autenticación');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 relative shadow-2xl border border-gray-100">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-[#FF441F] p-1 transition-colors cursor-pointer"
          title="Cerrar"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <div className="w-12 h-12 bg-orange-100 text-[#FF441F] rounded-full flex items-center justify-center mx-auto mb-3 shadow-xs">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-gray-900 tracking-tight">
            Autenticación & Control de Intentos
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            Limitador de consultas por usuario para la Prueba Técnica SP&A Rappi
          </p>
        </div>

        {currentSession?.isAdmin ? (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-center mb-6 space-y-2">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
              <ShieldCheck className="w-4 h-4" />
              <span>Administradora Autenticada</span>
            </div>
            <p className="text-xs font-semibold text-gray-800">
              {currentSession.email}
            </p>
            <p className="text-xs text-gray-600">
              Tienes <strong>Consultas Ilimitadas</strong> para evaluar y probar la aplicación.
            </p>
          </div>
        ) : (
          <div className="bg-orange-50/80 border border-orange-200 rounded-2xl p-4 mb-6">
            <div className="flex justify-between items-center text-xs font-bold text-gray-700 mb-1">
              <span>Estado Actual de Consultas:</span>
              <span className="text-[#FF441F] font-extrabold">
                {currentSession?.queriesRemaining || 0} / {currentSession?.maxQueries || 5} Disponibles
              </span>
            </div>
            <p className="text-[11px] text-gray-500 leading-relaxed">
              Las consultas invitadas están limitadas a 5 intentos. Al iniciar sesión como{' '}
              <strong>selene.jimenez.id@gmail.com</strong>, los intentos se desbloquean sin límites.
            </p>
          </div>
        )}

        {errorMsg && (
          <div className="bg-red-50 text-red-600 text-xs p-3 rounded-xl mb-4 font-semibold">
            {errorMsg}
          </div>
        )}

        <div className="space-y-3">
          {/* Quick Admin One-Click Google Login Button */}
          <button
            onClick={() => handleGoogleLogin('selene.jimenez.id@gmail.com', 'Selene Jiménez')}
            disabled={loading}
            className="w-full bg-[#FF441F] hover:bg-[#E33C1B] text-white py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer disabled:opacity-50"
            id="login-as-selene-btn"
          >
            <UserCheck className="w-4 h-4" />
            <span>Iniciar Sesión como Selene Jiménez (Admin - Ilimitado)</span>
          </button>

          {/* Standard Google Login simulation/option */}
          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-[10px] uppercase tracking-wider font-bold text-gray-400 bg-white px-2">
              o con otra cuenta de Google
            </div>
          </div>

          <div className="flex gap-2">
            <input
              type="email"
              value={customEmail}
              onChange={(e) => setCustomEmail(e.target.value)}
              placeholder="correo@google.com"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-xl text-xs focus:outline-none focus:border-[#FF441F]"
            />
            <button
              onClick={() => handleGoogleLogin(customEmail)}
              disabled={loading || !customEmail.includes('@')}
              className="bg-gray-900 hover:bg-black text-white px-4 py-2 rounded-xl text-xs font-semibold disabled:opacity-50 transition-colors cursor-pointer"
            >
              Google Login
            </button>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-gray-100 text-center text-[11px] text-gray-400">
          Autenticación vinculada a Google Workspace · Selene Jiménez SP&A
        </div>
      </div>
    </div>
  );
};
