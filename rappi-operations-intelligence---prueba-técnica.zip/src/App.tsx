import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatSection } from './components/ChatSection';
import { DashboardSection } from './components/DashboardSection';
import { PitchSection } from './components/PitchSection';
import { InfoModal } from './components/InfoModal';
import { DeleteModal } from './components/DeleteModal';
import { AuthModal } from './components/AuthModal';
import { UserSession } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<'chat' | 'dashboard' | 'pitch'>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [infoModalOpen, setInfoModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [resetTrigger, setResetTrigger] = useState(0);

  const [session, setSession] = useState<UserSession | null>(null);

  // Initialize or retrieve session ID
  useEffect(() => {
    let sid = localStorage.getItem('rappi_session_id');
    if (!sid) {
      sid = `session_${Math.random().toString(36).substring(2, 9)}`;
      localStorage.setItem('rappi_session_id', sid);
    }

    fetch('/api/auth/session', {
      headers: {
        'x-session-id': sid,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.session) {
          setSession(data.session);
        }
      })
      .catch((err) => console.error('Error loading user session:', err));
  }, []);

  const handleToggleSidebar = () => {
    setSidebarOpen((prev) => !prev);
  };

  const handleSwitchSection = (section: 'chat' | 'dashboard' | 'pitch') => {
    setActiveSection(section);
    // On small screens, auto-close sidebar on navigate
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleConfirmClearHistory = () => {
    localStorage.removeItem('rappi_chat_history');
    setDeleteModalOpen(false);
    setResetTrigger((prev) => prev + 1);
  };

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-gray-50 text-gray-900 font-sans">
      {/* Top Header */}
      <Header
        onToggleSidebar={handleToggleSidebar}
        session={session}
        onOpenAuthModal={() => setAuthModalOpen(true)}
      />

      {/* Main Body */}
      <div className="flex flex-1 overflow-hidden relative">
        <Sidebar
          isOpen={sidebarOpen}
          activeSection={activeSection}
          onSwitchSection={handleSwitchSection}
        />

        <main className="flex-1 flex flex-col h-full overflow-hidden relative">
          {activeSection === 'chat' && (
            <ChatSection
              onOpenInfoModal={() => setInfoModalOpen(true)}
              onOpenDeleteModal={() => setDeleteModalOpen(true)}
              resetTrigger={resetTrigger}
              session={session}
              onUpdateSession={(s) => setSession(s)}
              onOpenAuthModal={() => setAuthModalOpen(true)}
            />
          )}

          {activeSection === 'dashboard' && <DashboardSection />}

          {activeSection === 'pitch' && <PitchSection />}
        </main>
      </div>

      {/* Modals */}
      <InfoModal
        isOpen={infoModalOpen}
        onClose={() => setInfoModalOpen(false)}
      />

      <DeleteModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleConfirmClearHistory}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        currentSession={session}
        onLoginSuccess={(newSession) => setSession(newSession)}
      />
    </div>
  );
}
