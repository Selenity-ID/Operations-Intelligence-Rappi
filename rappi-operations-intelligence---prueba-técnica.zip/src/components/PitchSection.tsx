import React from 'react';
import {
  Flag,
  Layers,
  Network,
  Lightbulb,
  CheckCircle2,
  Github,
  ArrowRight,
  Database,
  Cpu,
  BarChart2,
  FileCode,
  UserCheck,
} from 'lucide-react';

export const PitchSection: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-50">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-100 text-[#FF441F] text-xs font-bold uppercase tracking-wider">
            <UserCheck className="w-3.5 h-3.5" />
            <span>Prueba Técnica - Selene Jiménez</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 tracking-tight">
            Resolución del Caso Técnico Rappi
          </h2>
          <p className="text-sm md:text-base text-gray-600 leading-relaxed">
            Democratización de datos operacionales mediante Inteligencia Artificial y
            automatización a nivel Data Warehouse.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Business Challenge */}
          <div className="md:col-span-2 bg-white rounded-2xl p-6 shadow-xs border border-gray-200 hover:border-[#FF441F] transition-all">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-[#FF441F] flex items-center justify-center mb-4">
              <Flag className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">El Desafío de Negocio</h3>
            <p className="text-xs md:text-sm text-gray-600 leading-relaxed">
              Los equipos de Strategy, Planning & Analytics (SP&A) en Rappi invierten horas
              en extraer respuestas de negocio de miles de filas de datos, requiriendo
              habilidades técnicas (SQL/Python). El objetivo de este MVP en esta{' '}
              <strong>Prueba Técnica</strong> es <strong>eliminar la fricción técnica</strong>,
              permitiendo a cualquier Operational Manager obtener insights, detectar anomalías
              y visualizar tendencias usando únicamente lenguaje natural.
            </p>
          </div>

          {/* Card 2: Tech Stack */}
          <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-200 hover:border-[#FF441F] transition-all">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-[#FF441F] flex items-center justify-center mb-4">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Tech Stack Elegido</h3>
            <p className="text-xs text-gray-500 mb-4">
              Arquitectura híbrida 100% Serverless enfocada en escalabilidad masiva (Big Data).
            </p>
            <div className="flex flex-wrap gap-2 text-xs font-semibold text-gray-700">
              <span className="bg-gray-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                <Database className="w-3.5 h-3.5 text-blue-600" />
                Google BigQuery
              </span>
              <span className="bg-gray-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-purple-600" />
                Gemini 3.6 Flash
              </span>
              <span className="bg-gray-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                <FileCode className="w-3.5 h-3.5 text-emerald-600" />
                Express + Node V8
              </span>
              <span className="bg-gray-100 px-2.5 py-1 rounded-lg flex items-center gap-1">
                <BarChart2 className="w-3.5 h-3.5 text-[#FF441F]" />
                ApexCharts
              </span>
            </div>
          </div>

          {/* Card 3: Architecture Diagram */}
          <div className="md:col-span-3 bg-white rounded-2xl p-6 shadow-xs border border-gray-200 hover:border-[#FF441F] transition-all">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-[#FF441F] flex items-center justify-center mb-4">
              <Network className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">
              Arquitectura de Procesamiento (El "Orquestador IA")
            </h3>
            <p className="text-xs text-gray-600 mb-6">
              Para evitar los límites de tokens y las alucinaciones comunes al pasar grandes
              bases de datos a un LLM, se implementó un pipeline desacoplado.{' '}
              <strong>Google BigQuery</strong> se encarga de la ejecución matemática pesada,
              mientras que Gemini se enfoca estrictamente en el enrutamiento semántico y la
              generación de reportes ejecutivos HTML.
            </p>

            {/* Flow Diagram */}
            <div className="bg-gray-50 border border-dashed border-gray-300 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4 overflow-x-auto">
              <div className="text-center min-w-[100px]">
                <div className="w-12 h-12 rounded-full bg-white border-2 border-[#FF441F] text-[#FF441F] flex items-center justify-center mx-auto mb-2 shadow-xs font-bold text-xs">
                  Usuario
                </div>
                <div className="text-xs font-bold text-gray-800">Pregunta NL</div>
                <div className="text-[10px] text-gray-400">Lenguaje Natural</div>
              </div>

              <ArrowRight className="w-5 h-5 text-gray-400 rotate-90 md:rotate-0" />

              <div className="text-center min-w-[110px]">
                <div className="w-12 h-12 rounded-full bg-white border-2 border-[#FF441F] text-[#FF441F] flex items-center justify-center mx-auto mb-2 shadow-xs font-bold text-xs">
                  Gemini (1)
                </div>
                <div className="text-xs font-bold text-gray-800">Router JSON</div>
                <div className="text-[10px] text-gray-400">Parseo a Filtros</div>
              </div>

              <ArrowRight className="w-5 h-5 text-gray-400 rotate-90 md:rotate-0" />

              <div className="text-center min-w-[110px]">
                <div className="w-12 h-12 rounded-full bg-white border-2 border-[#FF441F] text-[#FF441F] flex items-center justify-center mx-auto mb-2 shadow-xs font-bold text-xs">
                  BigQuery
                </div>
                <div className="text-xs font-bold text-gray-800">Ejecución SQL</div>
                <div className="text-[10px] text-gray-400">Filtrado & Math</div>
              </div>

              <ArrowRight className="w-5 h-5 text-gray-400 rotate-90 md:rotate-0" />

              <div className="text-center min-w-[110px]">
                <div className="w-12 h-12 rounded-full bg-white border-2 border-[#FF441F] text-[#FF441F] flex items-center justify-center mx-auto mb-2 shadow-xs font-bold text-xs">
                  Gemini (2)
                </div>
                <div className="text-xs font-bold text-gray-800">Insights Generator</div>
                <div className="text-[10px] text-gray-400">Renderizado HTML</div>
              </div>

              <ArrowRight className="w-5 h-5 text-gray-400 rotate-90 md:rotate-0" />

              <div className="text-center min-w-[100px]">
                <div className="w-12 h-12 rounded-full bg-white border-2 border-[#FF441F] text-[#FF441F] flex items-center justify-center mx-auto mb-2 shadow-xs font-bold text-xs">
                  UI / PDF
                </div>
                <div className="text-xs font-bold text-gray-800">Reporte Final</div>
                <div className="text-[10px] text-gray-400">Visualización</div>
              </div>
            </div>
          </div>

          {/* Card 4: Q&A */}
          <div className="md:col-span-2 bg-white rounded-2xl p-6 shadow-xs border border-gray-200 hover:border-[#FF441F] transition-all">
            <div className="w-10 h-10 rounded-xl bg-orange-100 text-[#FF441F] flex items-center justify-center mb-4">
              <Lightbulb className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Q&A: Decisiones de Diseño Estratégico
            </h3>
            <ul className="space-y-4 text-xs text-gray-600">
              <li>
                <strong className="text-gray-900 block text-sm mb-1">
                  ¿Por qué BigQuery en lugar de procesar los datos en memoria (Sheets)?
                </strong>
                Pensando en el entorno Enterprise de Rappi. Las bases de datos operacionales
                manejan millones de filas diarias. Al usar BigQuery como Data Warehouse central,
                garantizamos que el sistema escale sub-segundo desde miles de registros hasta
                decenas de millones, eliminando cuellos de botella.
              </li>
              <li>
                <strong className="text-gray-900 block text-sm mb-1">
                  ¿Cómo se maneja la latencia y la optimización de tokens?
                </strong>
                El bot NUNCA lee la base de datos completa en la ventana del LLM. Gemini
                traduce la intención a filtros estructurados, el backend compone la consulta SQL
                optimizada, y BigQuery ejecuta la agregación. Solo el micro-contexto resultante
                se envía a la IA.
              </li>
              <li>
                <strong className="text-gray-900 block text-sm mb-1">
                  ¿Cumple los requerimientos del 30% (Anomalías)?
                </strong>
                Sí. La función de escaneo de anomalías analiza caídas de rentabilidad superiores
                al 15% WoW de forma autónoma, inyectando alertas críticas en el Dashboard y en
                los reportes conversacionales.
              </li>
            </ul>
          </div>

          {/* Card 5: Added Value & GitHub Link */}
          <div className="bg-white rounded-2xl p-6 shadow-xs border border-gray-200 hover:border-[#FF441F] transition-all flex flex-col justify-between">
            <div>
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-[#FF441F] flex items-center justify-center mb-4">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Valor Añadido</h3>
              <p className="text-xs text-gray-600 leading-relaxed mb-4">
                La arquitectura destaca la implementación enfocada en{' '}
                <strong>Data Quality y escalabilidad Cloud</strong>.<br />
                <br />
                Incluye despliegue listo para GCP BigQuery, interfaz con estilo Rappi,
                gráficas dinámicas ApexCharts, parseo regional y exportación instantánea a PDF.
              </p>
            </div>

            <a
              href="https://github.com/Selenity-ID/Operations-Intelligence-Rappi"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-gray-900 hover:bg-black text-white text-xs font-semibold px-4 py-3 rounded-xl transition-all shadow-xs cursor-pointer text-center mt-2"
            >
              <Github className="w-4 h-4" />
              <span>Ver repositorio en GitHub</span>
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-gray-400 py-4 border-t border-gray-200">
          © 2026 Rappi · Operations Intelligence System. Prueba Técnica implementada por{' '}
          <strong className="text-gray-700">Selene Jiménez</strong>.
        </div>
      </div>
    </div>
  );
};
